public class CRC {

    // Generator polynomial
    private static final int[] GENERATOR_POLYNOMIAL = {1, 0, 1, 1};

    public static void main(String[] args) {
        int[] dataWord = {1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1};
        int[] remainder = calculateCRC(dataWord);

        System.out.print("Data Word: ");
        for (int bit : dataWord) {
            System.out.print(bit);
        }

        System.out.print("\nCRC: ");
        for (int bit : remainder) {
            System.out.print(bit);
        }
    }

    private static int[] calculateCRC(int[] dataWord) {
        int[] dividend = new int[dataWord.length + GENERATOR_POLYNOMIAL.length - 1];

        // Copy data word to dividend
        System.arraycopy(dataWord, 0, dividend, 0, dataWord.length);

        // Perform division
        for (int i = 0; i < dataWord.length; i++) {
            if (dividend[i] == 1) {
                for (int j = 0; j < GENERATOR_POLYNOMIAL.length; j++) {
                    dividend[i + j] ^= GENERATOR_POLYNOMIAL[j];
                }
            }
        }

        // Return remainder
        int[] remainder = new int[GENERATOR_POLYNOMIAL.length - 1];
        System.arraycopy(dividend, dataWord.length, remainder, 0, remainder.length);
        return remainder;
    }
}
