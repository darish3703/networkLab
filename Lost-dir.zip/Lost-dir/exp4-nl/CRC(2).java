import java.util.Scanner;

public class CRC {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the number of data bits
        System.out.println("Enter the number of data bits:");
        int dataBits = scanner.nextInt();

        // Get the data bits
        int[] data = new int[dataBits];
        System.out.println("Enter the data bits:");
        for (int i = 0; i < dataBits; i++) {
            data[i] = scanner.nextInt();
        }

        // Get the number of generator bits
        System.out.println("Enter the number of generator bits:");
        int generatorBits = scanner.nextInt();

        // Get the generator bits
        int[] generator = new int[generatorBits];
        System.out.println("Enter the generator bits:");
        for (int i = 0; i < generatorBits; i++) {
            generator[i] = scanner.nextInt();
        }

        // Append zeros to the data bits
        int[] appendedData = new int[dataBits + generatorBits - 1];
        System.arraycopy(data, 0, appendedData, 0, dataBits);

        // Perform CRC division
        int[] remainder = divide(appendedData, generator);

        // Append the remainder to the data bits to form the transmitted code word
        int[] transmittedCodeWord = new int[dataBits + generatorBits - 1];
        System.arraycopy(data, 0, transmittedCodeWord, 0, dataBits);
        System.arraycopy(remainder, 0, transmittedCodeWord, dataBits, generatorBits - 1);

        // Print the transmitted code word
        System.out.println("Transmitted code word is:");
        for (int i = 0; i < transmittedCodeWord.length; i++) {
            System.out.println(transmittedCodeWord[i]);
        }

        // Get the received code word
        System.out.println("At Receiver side, ");
        System.out.println("Enter the code word:");
        int[] receivedCodeWord = new int[dataBits + generatorBits - 1];
        for (int i = 0; i < receivedCodeWord.length; i++) {
            receivedCodeWord[i] = scanner.nextInt();
        }

        // Perform CRC division on the received code word
        remainder = divide(receivedCodeWord, generator);

        // Check if the received code word has errors
        boolean hasErrors = false;
        for (int i = 0; i < remainder.length; i++) {
            if (remainder[i] != 0) {
                hasErrors = true;
                break;
            }
        }

        // Print the result
        if (hasErrors) {
            System.out.println("As reminder is non zero, the received code word has errors.");
        } else {
            System.out.println("As reminder is zero, received code word has no errors.");
        }

        scanner.close();
    }

    public static int[] divide(int[] dividend, int[] divisor) {
        int[] remainder = new int[divisor.length];

        // Perform polynomial division
        System.arraycopy(dividend, 0, remainder, 0, divisor.length);
        for (int i = 0; i < dividend.length - divisor.length + 1; i++) {
            if (remainder[0] == 1) {
                for (int j = 1; j < divisor.length; j++) {
                    remainder[j - 1] = remainder[j] ^ divisor[j];
                }
            } else {
                for (int j = 1; j < divisor.length; j++) {
                    remainder[j - 1] = remainder[j];
                }
            }
        
        }
    }
}
           
